const CREATURE_CATALOG = {
    COMMUN: [
        { name: "Feuille Scintillante", image: "fieullescintillante-removebg-preview.png", baseValue: 25 },
        { name: "Kippi-Kippi", image: "kippi_kippi-removebg-preview.png", baseValue: 75 },
        { name: "Mico Monnaie", image: "mico_monais_-removebg-preview.png", baseValue: 100 }
    ],
    RARE_COMMUN: [
        { name: "Nubis Gemma", image: "nubis_gemma-removebg-preview.png", baseValue: 150 },
        { name: "Hibou Céleste", image: "hibou_celeste-removebg-preview.png", baseValue: 250 },
        { name: "Astro Lapin", image: "astro_lapin-removebg-preview.png", baseValue: 500 }
    ],
    EPIQUE: [
        { name: "Cinder Lord", image: "cinder_lord-removebg-preview.png", baseValue: 1000 },
        { name: "Ignis Wing", image: "ignis_wing-removebg-preview.png", baseValue: 2500 },
        { name: "Sigma", image: "sigma-removebg-preview.png", baseValue: 5000 }
    ],
    LEGENDAIRE: [
        { name: "Aigle Royale", image: "aigle_royale-removebg-preview.png", baseValue: 10000 },
        { name: "Licorne Scintillante", image: "licorne-scientillante-removebg-preview.png", baseValue: 20000 },
        { name: "Loup Obscur", image: "loup_obscure-removebg-preview.png", baseValue: 50000 }
    ]
};

const EGG_TYPES = [
    { name: "Commun", rarity: 50, clicks: 15, image: "oeuf_commun_-removebg-preview.png", creatureSetKey: 'COMMUN' },
    { name: "Rare Commun", rarity: 25, clicks: 20, image: "oeuf_in-removebg-preview.png", creatureSetKey: 'RARE_COMMUN' },
    { name: "Épique", rarity: 20, clicks: 40, image: "oeuf_epic-removebg-preview.png", creatureSetKey: 'EPIQUE' },
    { name: "Légendaire", rarity: 5, clicks: 100, image: "oeuf_legendaire_-removebg-preview.png", creatureSetKey: 'LEGENDAIRE' }
];

let money = 0;
let currentClicks = 0;
let currentEgg = EGG_TYPES[0];
let inventory = [];
let slots = [
    { unlocked: true, creature: null },
    { unlocked: true, creature: null },
    { unlocked: true, creature: null },
    { unlocked: false, price: 100000, creature: null },
    { unlocked: false, price: 500000, creature: null },
    { unlocked: false, price: 2000000, creature: null }
];

// --- SAUVEGARDE ---
function saveGame() {
    localStorage.setItem('creatureClickerXL', JSON.stringify({ money, currentClicks, currentEgg, inventory, slots }));
}

function loadGame() {
    const saved = localStorage.getItem('creatureClickerXL');
    if (saved) {
        const data = JSON.parse(saved);
        money = data.money || 0;
        currentClicks = data.currentClicks || 0;
        currentEgg = data.currentEgg || EGG_TYPES[0];
        inventory = data.inventory || [];
        slots = data.slots || slots;
    }
}

// --- NOTIFICATIONS & AFFICHAGE ---
function showNotification(msg, type = "normal") {
    const area = document.getElementById('notification-area');
    if(!area) return;
    const notif = document.createElement('div');
    notif.className = `notification ${type}`;
    notif.textContent = msg;
    area.appendChild(notif);
    setTimeout(() => notif.remove(), 3000);
}

function updateDisplay() {
    document.getElementById('current-money').textContent = Math.floor(money).toLocaleString() + " €";
    document.getElementById('click-counter').textContent = `CLICS : ${currentClicks} / ${currentEgg.clicks}`;
    document.getElementById('egg').src = currentEgg.image;
    const percent = (currentClicks / currentEgg.clicks) * 100;
    document.getElementById('click-progress-bar').style.width = percent + "%";
}

// --- CLIC & ECLOSION ---
document.getElementById('egg').addEventListener('click', function() {
    currentClicks++;
    money += 10;
    this.classList.remove('shake');
    void this.offsetWidth; 
    this.classList.add('shake');
    updateDisplay();
    if (currentClicks >= currentEgg.clicks) hatch();
    saveGame();
});

function hatch() {
    const list = CREATURE_CATALOG[currentEgg.creatureSetKey];
    const creature = { ...list[Math.floor(Math.random() * list.length)] };
    creature.rarityName = currentEgg.name;
    inventory.push(creature);
    showNotification(`🎉 ${creature.name} obtenu !`, "success");

    let rand = Math.random() * 100;
    let cum = 0;
    for (const egg of EGG_TYPES) {
        cum += egg.rarity;
        if (rand <= cum) {
            currentEgg = egg;
            break;
        }
    }
    currentClicks = 0;
    updateDisplay();
    renderSlotsAroundEgg();
    saveGame();
}

// --- SLOTS & INVENTAIRE ---
function renderSlotsAroundEgg() {
    const left = document.getElementById('slots-left');
    const right = document.getElementById('slots-right');
    left.innerHTML = ''; right.innerHTML = '';

    slots.forEach((slot, i) => {
        const div = document.createElement('div');
        div.className = 'slot';
        if (slot.unlocked && slot.creature) {
            div.innerHTML = `<img src="${slot.creature.image}"><span>+${slot.creature.baseValue}€/s</span><button onclick="removeCreature(${i})" style="cursor:pointer; background:red; color:white; border:none; padding:2px; font-size:10px; border-radius:3px;">X</button>`;
        } else if (slot.unlocked) {
            div.innerHTML = '<p>VIDE<br><small>cliquer</small></p>';
            div.style.cursor = "pointer";
            div.onclick = openInventory;
        } else {
            div.innerHTML = '<p>🔒 BLOQUÉ</p>';
        }
        if (i < 3) left.appendChild(div); else right.appendChild(div);
    });
}

function openInventory() {
    document.getElementById('inventory-modal').style.display = 'flex';
    renderInventory();
}

function renderInventory() {
    const list = document.getElementById('storage-list');
    list.innerHTML = '';
    if (inventory.length === 0) { list.innerHTML = '<p>Vide</p>'; return; }
    inventory.forEach((c, i) => {
        const item = document.createElement('div');
        item.className = 'storage-item';
        item.innerHTML = `<img src="${c.image}"><p>${c.name}</p><button class="place-btn">PLACER</button>`;
        item.querySelector('.place-btn').onclick = () => {
            const freeSlot = slots.find(s => s.unlocked && !s.creature);
            if (freeSlot) {
                freeSlot.creature = inventory.splice(i, 1)[0];
                renderSlotsAroundEgg();
                renderInventory();
                saveGame();
            } else { showNotification("Pas de slot !"); }
        };
        list.appendChild(item);
    });
}

window.removeCreature = function(index) {
    inventory.push(slots[index].creature);
    slots[index].creature = null;
    renderSlotsAroundEgg();
    saveGame();
};

// --- COLLECTION ---
function renderFullCollection() {
    const container = document.getElementById('full-collection');
    container.innerHTML = '';
    const allPossible = [];
    Object.values(CREATURE_CATALOG).forEach(set => set.forEach(c => allPossible.push(c)));
    
    // On vérifie ce qu'on possède
    const ownedNames = new Set([...inventory, ...slots.filter(s => s.creature).map(s => s.creature)].map(c => c.name));

    allPossible.forEach(c => {
        const isOwned = ownedNames.has(c.name);
        const div = document.createElement('div');
        div.className = `collection-creature ${isOwned ? '' : 'unowned'}`;
        div.innerHTML = `<img src="${c.image}"><p>${isOwned ? c.name : '???'}</p><p>+${c.baseValue}€/s</p>`;
        container.appendChild(div);
    });
    document.getElementById('collected-count').textContent = ownedNames.size;
}

// --- MENU & BOUTONS ---
document.getElementById('open-menu-btn').onclick = () => document.getElementById('side-menu').classList.add('open');
document.getElementById('close-menu-btn').onclick = () => document.getElementById('side-menu').classList.remove('open');
document.getElementById('open-inventory-btn-top').onclick = openInventory;
document.getElementById('close-inventory-btn').onclick = () => document.getElementById('inventory-modal').style.display = 'none';

document.querySelectorAll('.menu-btn').forEach(btn => {
    btn.onclick = () => {
        document.querySelectorAll('.menu-btn').forEach(b => b.classList.remove('active'));
        document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
        btn.classList.add('active');
        document.getElementById(btn.dataset.tab + '-tab').classList.add('active');
        document.getElementById('side-menu').classList.remove('open');
        if (btn.dataset.tab === 'collection') renderFullCollection();
    };
});

// --- BOUTIQUE ---
document.querySelectorAll('.buy-btn').forEach(btn => {
    btn.onclick = () => {
        const type = btn.dataset.type;
        let cost = 0;
        if(type === 'rare-egg') cost = 50000;
        else if(type === 'epic-egg') cost = 200000;
        else if(type === 'legendary-egg') cost = 1000000;

        if (type !== 'extra-slot' && money >= cost) {
            money -= cost;
            currentEgg = EGG_TYPES[type === 'rare-egg' ? 1 : (type === 'epic-egg' ? 2 : 3)];
            currentClicks = 0;
            showNotification("Acheté !");
            document.querySelector('.menu-btn[data-tab="clicker"]').click();
        } else if (type === 'extra-slot') {
            const next = slots.find(s => !s.unlocked);
            if (next && money >= next.price) {
                money -= next.price;
                next.unlocked = true;
                showNotification("Slot débloqué !");
            } else { showNotification("Pas assez d'argent"); }
        } else { showNotification("Pas assez d'argent"); }
        updateDisplay();
        saveGame();
    };
});

// --- REVENU PASSIF ---
setInterval(() => {
    let income = 0;
    slots.forEach(s => { if (s.unlocked && s.creature) income += s.creature.baseValue; });
    if (income > 0) { money += income; updateDisplay(); }
}, 1000);

window.onload = () => { loadGame(); updateDisplay(); renderSlotsAroundEgg(); renderFullCollection(); };